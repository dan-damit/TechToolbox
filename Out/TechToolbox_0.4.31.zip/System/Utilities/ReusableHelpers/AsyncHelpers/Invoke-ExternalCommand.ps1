function Invoke-ExternalCommand {
    <#
    .SYNOPSIS
        Invokes an external command with arguments, with optional elevation and
        timeout.
    .DESCRIPTION
        This function is designed to safely invoke external commands (e.g.,
        .exe, .ms i, .cmd, .bat) with arguments, while providing features like:
        - Automatic resolution of command names to full paths
        - Optional timeout with automatic termination
        - Optional elevation (UAC prompt)
        - Progress display with spinner and timeout countdown
        - Structured result object with metadata
    .PARAMETER FilePath
        The path to the executable or command name to invoke. Command names will
        be resolved using Get-Command.
    .PARAMETER Arguments
        An array of arguments to pass to the command.
    .PARAMETER TimeoutMinutes
        Maximum time to allow the command to run before forcefully terminating
        it.
    .PARAMETER Quiet
        If set, suppresses logging output about the command's success or
        failure.
    .PARAMETER Tag
        An optional string tag to include in log messages for easier
        correlation.
    .PARAMETER RequiresElevation
        If set, the command will be invoked with elevation, prompting the user
        with a UAC dialog if necessary.
    .PARAMETER ShowProgress
        If set, displays a spinner and timeout countdown in the console while
        the command is running.
    .OUTPUTS
        A custom object with the following properties:
        - FilePath: The resolved file path of the command that was invoked.
        - Arguments: The arguments that were passed to the command.
        - ExitCode: The exit code returned by the command (or -1 if timed out).
        - TimedOut: A boolean indicating whether the command was terminated due
          to timeout.
        - WorkerStarted: Timestamp when the worker process started executing the
          command.
        - WorkerFinished: Timestamp when the worker process finished executing
          the command.
        - Success: A boolean indicating whether the command completed
          successfully (not timed out and exit code 0).
        - Tag: The tag string provided in the input parameters.
        - RequiresElevation: Indicates whether elevation was requested for this
          command.
        - WorkerScript: The path to the worker script that was used to execute
          this command.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$FilePath,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [string[]]$Arguments,

        [int]$TimeoutMinutes = 30,

        [switch]$Quiet,
        [string]$Tag,

        [switch]$RequiresElevation,
        [switch]$ShowProgress
    )

    $ps64 = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $tagPrefix = if ($Tag) { "[$Tag] " } else { "" }

    # --- Worker script location ---
    # Remote (ephemeral): $script:TT.WorkersRoot\Invoke-ExternalCommand.Worker.ps1
    # Local fallback:     <ModuleRoot>\Workers\Invoke-ExternalCommand.Worker.ps1
    $workerScript =
    if ($script:TT -and $script:TT.WorkersRoot) {
        Join-Path $script:TT.WorkersRoot 'Invoke-ExternalCommand.Worker.ps1'
    }
    else {
        $moduleRoot = Get-ModuleRoot
        Join-Path $moduleRoot 'Workers\Invoke-ExternalCommand.Worker.ps1'
    }

    if (-not (Test-Path -LiteralPath $workerScript)) {
        throw "Invoke-ExternalCommand: Worker script not found: $workerScript"
    }

    # Worker meta log file
    $tempOut = Join-Path $env:TEMP ("TechToolbox_InvokeExternal_" + [guid]::NewGuid() + ".log")

    # --- Resolve FilePath ---
    try {
        if (Test-Path -LiteralPath $FilePath) {
            $resolvedFilePath = (Resolve-Path -LiteralPath $FilePath -ErrorAction Stop).Path
        }
        else {
            $cmdInfo = Get-Command -Name $FilePath -ErrorAction Stop
            $resolvedFilePath = $cmdInfo.Path
            if ([string]::IsNullOrWhiteSpace($resolvedFilePath)) {
                $resolvedFilePath = $cmdInfo.Source
            }
        }

        if ([string]::IsNullOrWhiteSpace($resolvedFilePath)) {
            throw "Resolved path was empty."
        }
    }
    catch {
        throw "Invoke-ExternalCommand: FilePath '$FilePath' could not be resolved to an executable. $($_.Exception.Message)"
    }

    # Normalize arguments
    [string[]]$normalizedArgs = @($Arguments)

    # Build payload
    $payloadObject = @{
        FilePath          = $resolvedFilePath
        Arguments         = $normalizedArgs
        OutputPath        = $tempOut
        RequiresElevation = [bool]$RequiresElevation
        TimeoutMinutes    = $TimeoutMinutes
        Tag               = $Tag
    }

    $json = $payloadObject | ConvertTo-Json -Depth 6 -Compress
    $payload = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($json))

    if ([string]::IsNullOrWhiteSpace($payload)) {
        throw "Invoke-ExternalCommand: Payload unexpectedly empty (json length = $($json.Length))."
    }

    # Build encoded command to invoke the worker safely.
    # Use single quotes to avoid escaping; Base64 will not contain single quotes.
    $ws = $workerScript.Replace("'", "''")
    $cmd = "& '$ws' -Payload '$payload'"
    $encoded = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($cmd))

    # Launch worker
    $proc = Start-Process $ps64 `
        -WindowStyle Hidden `
        -ArgumentList @(
        "-NoLogo",
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy", "Bypass",
        "-EncodedCommand", $encoded
    ) `
        -PassThru

    function Test-TTVirtualTerminal {
        try {
            if ($Host.UI -and $Host.UI.PSObject.Properties.Name -contains 'SupportsVirtualTerminal') {
                return [bool]$Host.UI.SupportsVirtualTerminal
            }
            if ($env:WT_SESSION) { return $true }
            if ($env:TERM_PROGRAM -eq 'vscode') { return $true }
            return $false
        }
        catch { return $false }
    }

    function Write-TTStatusLine {
        param(
            [Parameter(Mandatory)][string]$Text,
            [int]$MinWidth = 80
        )
        $width = $MinWidth
        try { $width = [Math]::Max($MinWidth, $Host.UI.RawUI.BufferSize.Width - 1) } catch { }
        if ($Text.Length -ge $width) { $Text = $Text.Substring(0, $width - 1) }
        else { $Text = $Text.PadRight($width - 1) }

        [Console]::Write("`r$Text")
    }

    $timeoutMs = [int][TimeSpan]::FromMinutes([Math]::Max(1, $TimeoutMinutes)).TotalMilliseconds
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    $vtOk = $ShowProgress -and (Test-TTVirtualTerminal)

    $spinnerFramesFancy = @('⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏')
    $spinnerFramesAscii = @('|', '/', '-', '\')
    $pulseIndex = 0
    $heartbeatEveryMs = 60000  # 60 seconds
    $lastHeartbeatMs = [Environment]::TickCount64
    $cursorHidden = $false

    try {
        if ($ShowProgress) {
            if ($vtOk) {
                Write-Host "`e[?25l" -NoNewline
                $cursorHidden = $true
                Write-Host ""  # start spinner on its own line
            }
            else {
                [Console]::WriteLine()  # start spinner on its own line
            }
        }

        while (-not $proc.HasExited) {

            if ($sw.ElapsedMilliseconds -ge $timeoutMs) {
                try { $proc.Kill() } catch {}
                break
            }

            if ($ShowProgress) {
                $pct = [math]::Min(100, [math]::Floor(($sw.ElapsedMilliseconds / $timeoutMs) * 100))

                $remainingMs = [math]::Max(0, $timeoutMs - $sw.ElapsedMilliseconds)
                $remaining = [TimeSpan]::FromMilliseconds($remainingMs)
                $remainingStr = "{0:D2}m {1:D2}s" -f $remaining.Minutes, $remaining.Seconds

                if ($vtOk) {
                    $spinner = $spinnerFramesFancy[$pulseIndex % $spinnerFramesFancy.Count]
                    $pulseIndex++

                    # Clear line + redraw (ANSI)
                    $line = "`e[2K`r`e[33m$spinner`e[0m  `e[97m$pct%`e[0m  `e[37m(Timeout: $remainingStr)`e[0m"
                    Write-Host -NoNewline $line
                }
                else {
                    $spinner = $spinnerFramesAscii[$pulseIndex % $spinnerFramesAscii.Count]
                    $pulseIndex++

                    # No ANSI: always single-line via Console.Write + padding
                    Write-TTStatusLine -Text ("{0}  {1}%  (Timeout: {2})" -f $spinner, $pct, $remainingStr)

                    # Heartbeat: if we're on a long-running command, we want to
                    # periodically print a clean status line with timestamp to
                    # reassure the user that things are still running and
                    # haven't frozen. We also want to do this in VT mode, but
                    # it's especially important in non-VT mode where the spinner
                    # is more primitive and doesn't redraw in-place.
                    if ($ShowProgress) {
                        $nowMs = [Environment]::TickCount64
                        if (($nowMs - $lastHeartbeatMs) -ge $heartbeatEveryMs) {
                            $lastHeartbeatMs = $nowMs

                            # Finish the current in-place line cleanly
                            [Console]::WriteLine()

                            # Print a single heartbeat line (no ANSI needed)
                            Write-Host ("[{0}] Still running... {1}% (Timeout: {2})" -f (Get-Date -Format 'HH:mm:ss'), $pct, $remainingStr)
                        }
                    }
                }
            }

            Start-Sleep -Milliseconds 250
        }
    }
    finally {
        if ($ShowProgress) {
            if ($vtOk) {
                Write-Host "`e[2K`r" -NoNewline
                if ($cursorHidden) { Write-Host "`e[?25h" -NoNewline }
                Write-Host ""
            }
            else {
                # finish spinner line
                [Console]::WriteLine()
            }
        }
    }

    $timedOut = (-not $proc.HasExited)
    if (-not $timedOut) { $proc.WaitForExit() }

    $exitCode = if ($proc.HasExited) { $proc.ExitCode } else { -1 }

    # --- META-only worker log parsing ---
    $workerMeta = @{
        WorkerStarted  = $null
        WorkerFinished = $null
        ExitCode       = $exitCode
        TimedOut       = $timedOut
    }

    if (Test-Path -LiteralPath $tempOut) {
        $lines = Get-Content -LiteralPath $tempOut -Encoding UTF8

        foreach ($line in $lines) {
            if ($line -like '[META] WorkerStarted=*') {
                $workerMeta.WorkerStarted = $line.Substring(22)
            }
            elseif ($line -like '[META] WorkerFinished=*') {
                $workerMeta.WorkerFinished = $line.Substring(23)
            }
            elseif ($line -like '[META] ExitCode=*') {
                $workerMeta.ExitCode = [int]$line.Substring(17)
            }
            elseif ($line -like '[META] TimedOut=*') {
                $workerMeta.TimedOut = [bool]::Parse($line.Substring(16))
            }
        }

        Remove-Item -LiteralPath $tempOut -Force -ErrorAction SilentlyContinue
    }

    # --- Clean success/failure branching ---
    if (-not $Quiet) {
        if ($workerMeta.TimedOut) {
            Write-Host ("{0}Timeout after {1} minutes." -f $tagPrefix, $TimeoutMinutes)
        }
        elseif ($workerMeta.ExitCode -eq 0) {
            Write-Host ("{0}Command completed successfully." -f $tagPrefix)
        }
        else {
            Write-Host ("{0}Command failed with exit code {1}." -f $tagPrefix, $workerMeta.ExitCode)
        }
    }

    # Return result object
    [pscustomobject]@{
        FilePath          = $FilePath
        Arguments         = $Arguments
        ExitCode          = $workerMeta.ExitCode
        TimedOut          = $workerMeta.TimedOut
        WorkerStarted     = $workerMeta.WorkerStarted
        WorkerFinished    = $workerMeta.WorkerFinished
        Success           = (-not $workerMeta.TimedOut -and $workerMeta.ExitCode -eq 0)
        Tag               = $Tag
        RequiresElevation = [bool]$RequiresElevation
        WorkerScript      = $workerScript
    }
}

# SIG # Begin signature block
# MIIfAgYJKoZIhvcNAQcCoIIe8zCCHu8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDUQ2VG9P+4SmxC
# qXv3IdEzYIEfVqFHNpaVqtW3YxRqXKCCGEowggUMMIIC9KADAgECAhAR+U4xG7FH
# qkyqS9NIt7l5MA0GCSqGSIb3DQEBCwUAMB4xHDAaBgNVBAMME1ZBRFRFSyBDb2Rl
# IFNpZ25pbmcwHhcNMjUxMjE5MTk1NDIxWhcNMjYxMjE5MjAwNDIxWjAeMRwwGgYD
# VQQDDBNWQURURUsgQ29kZSBTaWduaW5nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8A
# MIICCgKCAgEA3pzzZIUEY92GDldMWuzvbLeivHOuMupgpwbezoG5v90KeuN03S5d
# nM/eom/PcIz08+fGZF04ueuCS6b48q1qFnylwg/C/TkcVRo0WFcKoFGT8yGxdfXi
# caHtapZfbSRh73r7qR7w0CioVveNBVgfMsTgE0WKcuwxemvIe/ptmkfzwAiw/IAC
# Ib0E0BjiX4PySbwWy/QKy/qMXYY19xpRItVTKNBtXzADUtzPzUcFqJU83vM2gZFs
# Or0MhPvM7xEVkOWZFBAWAubbMCJ3rmwyVv9keVDJChhCeLSz2XR11VGDOEA2OO90
# Y30WfY9aOI2sCfQcKMeJ9ypkHl0xORdhUwZ3Wz48d3yJDXGkduPm2vl05RvnA4T6
# 29HVZTmMdvP2475/8nLxCte9IB7TobAOGl6P1NuwplAMKM8qyZh62Br23vcx1fXZ
# TJlKCxBFx1nTa6VlIJk+UbM4ZPm954peB/fIqEacm8LkZ0cPwmLE5ckW7hfK4Trs
# o+RaudU1sKeA+FvpOWgsPccVRWcEYyGkwbyTB3xrIBXA+YckbANZ0XL7fv7x29hn
# gXbZipGu3DnTISiFB43V4MhNDKZYfbWdxze0SwLe8KzIaKnwlwRgvXDMwXgk99Mi
# EbYa3DvA/5ZWikLW9PxBFD7Vdr8ZiG/tRC9I2Y6fnb+PVoZKc/2xsW0CAwEAAaNG
# MEQwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQW
# BBRfYLVE8caSc990rnrIHUjoB7X/KjANBgkqhkiG9w0BAQsFAAOCAgEAiGB2Wmk3
# QBtd1LcynmxHzmu+X4Y5DIpMMNC2ahsqZtPUVcGqmb5IFbVuAdQphL6PSrDjaAR8
# 1S8uTfUnMa119LmIb7di7TlH2F5K3530h5x8JMj5EErl0xmZyJtSg7BTiBA/UrMz
# 6WCf8wWIG2/4NbV6aAyFwIojfAcKoO8ng44Dal/oLGzLO3FDE5AWhcda/FbqVjSJ
# 1zMfiW8odd4LgbmoyEI024KkwOkkPyJQ2Ugn6HMqlFLazAmBBpyS7wxdaAGrl18n
# 6bS7QuAwCd9hitdMMitG8YyWL6tKeRSbuTP5E+ASbu0Ga8/fxRO5ZSQhO6/5ro1j
# PGe1/Kr49Uyuf9VSCZdNIZAyjjeVAoxmV0IfxQLKz6VOG0kGDYkFGskvllIpQbQg
# WLuPLJxoskJsoJllk7MjZJwrpr08+3FQnLkRuisjDOc3l4VxFUsUe4fnJhMUONXT
# Sk7vdspgxirNbLmXU4yYWdsizz3nMUR0zebUW29A+HYme16hzrMPOeyoQjy4I5XX
# 3wXAFdworfPEr/ozDFrdXKgbLwZopymKbBwv6wtT7+1zVhJXr+jGVQ1TWr6R+8ea
# tIOFnY7HqGaxe5XB7HzOwJKdj+bpHAfXft1vUoiKr16VajLigcYCG8MdwC3sngO3
# JDyv2V+YMfsYBmItMGBwvizlQ6557NbK95EwggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwgga0MIIEnKADAgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqG
# SIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRy
# dXN0ZWQgUm9vdCBHNDAeFw0yNTA1MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYg
# MjAyNSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphB
# cr48RsAcrHXbo0ZodLRRF51NrY0NlLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6p
# vF4uGjwjqNjfEvUi6wuim5bap+0lgloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHe
# HYNnQxqXmRinvuNgxVBdJkf77S2uPoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEd
# gkFiDNYiOTx4OtiFcMSkqTtF2hfQz3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjU
# jsZvkgFkriK9tUKJm/s80FiocSk1VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bR
# VFLeGkuAhHiGPMvSGmhgaTzVyhYn4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeS
# LsJygoLPp66bkDX1ZlAeSpQl92QOMeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIV
# NSaz7BX8VtYGqLt9MmeOreGPRdtBx3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL
# 6s36czwzsucuoKs7Yk/ehb//Wx+5kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2Zd
# SoQbU2rMkpLiQ6bGRinZbI4OLu9BMIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFU
# eEY0qVjPKOWug/G6X5uAiynM7Bu2ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/
# BAgwBgEB/wIBADAdBgNVHQ4EFgQU729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0j
# BBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8E
# PDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEw
# DQYJKoZIhvcNAQELBQADggIBABfO+xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/
# T8ObXAZz8OjuhUxjaaFdleMM0lBryPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQ
# E7jU/kXjjytJgnn0hvrV6hqWGd3rLAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9r
# EVKChHyfpzee5kH0F8HABBgr0UdqirZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y
# 1IsA0QF8dTXqvcnTmpfeQh35k5zOCPmSNq1UH410ANVko43+Cdmu4y81hjajV/gx
# dEkMx1NKU4uHQcKfZxAvBAKqMVuqte69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3t
# y9qIijanrUR3anzEwlvzZiiyfTPjLbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcy
# tL5TTLL4ZaoBdqbhOhZ3ZRDUphPvSRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEB
# YTptMSbhdhGQDpOXgpIUsWTjd6xpR6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud
# /v4+7RWsWCiKi9EOLLHfMR2ZyJ/+xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiS
# uEtQvLsNz3Qbp7wGWqbIiOWCnb5WqxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZP
# ubdcMIIG7TCCBNWgAwIBAgIQCoDvGEuN8QWC0cR2p5V0aDANBgkqhkiG9w0BAQsF
# ADBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hB
# MjU2IDIwMjUgQ0ExMB4XDTI1MDYwNDAwMDAwMFoXDTM2MDkwMzIzNTk1OVowYzEL
# MAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJE
# aWdpQ2VydCBTSEEyNTYgUlNBNDA5NiBUaW1lc3RhbXAgUmVzcG9uZGVyIDIwMjUg
# MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANBGrC0Sxp7Q6q5gVrMr
# V7pvUf+GcAoB38o3zBlCMGMyqJnfFNZx+wvA69HFTBdwbHwBSOeLpvPnZ8ZN+vo8
# dE2/pPvOx/Vj8TchTySA2R4QKpVD7dvNZh6wW2R6kSu9RJt/4QhguSssp3qome7M
# rxVyfQO9sMx6ZAWjFDYOzDi8SOhPUWlLnh00Cll8pjrUcCV3K3E0zz09ldQ//nBZ
# ZREr4h/GI6Dxb2UoyrN0ijtUDVHRXdmncOOMA3CoB/iUSROUINDT98oksouTMYFO
# nHoRh6+86Ltc5zjPKHW5KqCvpSduSwhwUmotuQhcg9tw2YD3w6ySSSu+3qU8DD+n
# igNJFmt6LAHvH3KSuNLoZLc1Hf2JNMVL4Q1OpbybpMe46YceNA0LfNsnqcnpJeIt
# K/DhKbPxTTuGoX7wJNdoRORVbPR1VVnDuSeHVZlc4seAO+6d2sC26/PQPdP51ho1
# zBp+xUIZkpSFA8vWdoUoHLWnqWU3dCCyFG1roSrgHjSHlq8xymLnjCbSLZ49kPmk
# 8iyyizNDIXj//cOgrY7rlRyTlaCCfw7aSUROwnu7zER6EaJ+AliL7ojTdS5PWPsW
# eupWs7NpChUk555K096V1hE0yZIXe+giAwW00aHzrDchIc2bQhpp0IoKRR7YufAk
# prxMiXAJQ1XCmnCfgPf8+3mnAgMBAAGjggGVMIIBkTAMBgNVHRMBAf8EAjAAMB0G
# A1UdDgQWBBTkO/zyMe39/dfzkXFjGVBDz2GM6DAfBgNVHSMEGDAWgBTvb1NK6eQG
# fHrK4pBW9i/USezLTjAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYB
# BQUHAwgwgZUGCCsGAQUFBwEBBIGIMIGFMCQGCCsGAQUFBzABhhhodHRwOi8vb2Nz
# cC5kaWdpY2VydC5jb20wXQYIKwYBBQUHMAKGUWh0dHA6Ly9jYWNlcnRzLmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEy
# NTYyMDI1Q0ExLmNydDBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vY3JsMy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hB
# MjU2MjAyNUNBMS5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcB
# MA0GCSqGSIb3DQEBCwUAA4ICAQBlKq3xHCcEua5gQezRCESeY0ByIfjk9iJP2zWL
# pQq1b4URGnwWBdEZD9gBq9fNaNmFj6Eh8/YmRDfxT7C0k8FUFqNh+tshgb4O6Lgj
# g8K8elC4+oWCqnU/ML9lFfim8/9yJmZSe2F8AQ/UdKFOtj7YMTmqPO9mzskgiC3Q
# YIUP2S3HQvHG1FDu+WUqW4daIqToXFE/JQ/EABgfZXLWU0ziTN6R3ygQBHMUBaB5
# bdrPbF6MRYs03h4obEMnxYOX8VBRKe1uNnzQVTeLni2nHkX/QqvXnNb+YkDFkxUG
# tMTaiLR9wjxUxu2hECZpqyU1d0IbX6Wq8/gVutDojBIFeRlqAcuEVT0cKsb+zJNE
# suEB7O7/cuvTQasnM9AWcIQfVjnzrvwiCZ85EE8LUkqRhoS3Y50OHgaY7T/lwd6U
# Arb+BOVAkg2oOvol/DJgddJ35XTxfUlQ+8Hggt8l2Yv7roancJIFcbojBcxlRcGG
# 0LIhp6GvReQGgMgYxQbV1S3CrWqZzBt1R9xJgKf47CdxVRd/ndUlQ05oxYy2zRWV
# FjF7mcr4C34Mj3ocCVccAvlKV9jEnstrniLvUxxVZE/rptb7IRE2lskKPIJgbaP5
# t2nGj/ULLi49xTcBZU8atufk+EMF/cWuiC7POGT75qaL6vdCvHlshtjdNXOCIUjs
# arfNZzGCBg4wggYKAgEBMDIwHjEcMBoGA1UEAwwTVkFEVEVLIENvZGUgU2lnbmlu
# ZwIQEflOMRuxR6pMqkvTSLe5eTANBglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3
# AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisG
# AQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCAVFyO0S+0N
# GWnqsEM6h975FVuMUBERj5mY40GI+4z3RzANBgkqhkiG9w0BAQEFAASCAgDAKOXK
# cjaH+KBK3aWnhdkd09UtSpgisPuQ7sCWcMU64Kqe58z2LT80HbGfJj9Owb6R8ocg
# SJQhjPUyj+vvYW2SMpsDUFp3Fl2vuIj1ROZDbEu0fe28P0iFX2C+7lM94s1XVOJn
# bu1EzU7jAsb2+TieNY2Nmb1gMut5n8xTdtQevxpU+03tuIGAjP/0Z0mLx37PAfiD
# yHrDRXAlRAcqoOlg60BDHqwxDOMoZP455oapKbcOZHIF7bjRZa/HfHScA1g7XhRZ
# 52XLLFL28+ldc4/1Cqt3kQ+lg4R1iDrq2ZfGQmvnq41GuMMbxOc86vUPXzvxBGtS
# 0IQ4jnF7/p8v5zcRzQ6K8AbjqDYSw3ksPu291d7gi31az2tSXSYuRRTO9rv/lFnM
# NrXL6bxbwUJulCwIw1F0hbVe9geRRbAVaaWmHIOhwnDgvYcYy/Wt/QCxVgWfF6No
# mXDmitMd/GtVSM3WWeaAiCymC0gI9arSNTi4yUonLJHibqt17fytzW1bNZ6I08j8
# jYu228bnGdWXLeYKWC1EBy+tme8S1HsKb8goTTTMbQQ8dOP5R7erSWqQ0Fdwhe2t
# 1XBTZdxnEKpzqGplVb9v/WfejhkRMMpeovHl8hnVVa0Jy4c3bnm043ySHCqBdT8o
# /isznYO4CJasT/ggRe4QQW+MZ2mDJSqAqAy/a6GCAyYwggMiBgkqhkiG9w0BCQYx
# ggMTMIIDDwIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcg
# UlNBNDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgwDQYJYIZI
# AWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJ
# BTEPFw0yNjAzMDkyMTA0MzVaMC8GCSqGSIb3DQEJBDEiBCADg3V9T+CIis+Asy0e
# 0nDa1dIMnsGJopj0Z1thamKv+TANBgkqhkiG9w0BAQEFAASCAgDISpnwYSUeH+aw
# ltjZIgVHVZTywMUjNsDTgWwITHuYT7iHtwH4HaGAyXR37yuAe9YrflAaC8CFh2bv
# e1ALZ8MhSzW28m59/KBRGrG5QdaU6x/wlsz+tEsxB5+RBEObRvYIBpwIYZsBq5Nm
# gOPLVhh05Ck6sjTybvakSHsMo340KxjXUTaMGyEXEr7sr3DHTFfhqJnMUIYqppC7
# 5mDaJFbmCX146m6NryqM2JZf+m7DdJun1vLIv5DY5AEHDUnThIDlkAw3t0adwsNw
# zbyagt7pbCaI1BPqGd3p9Zgfm9g7ouE5pRUzgSp5em9V6yL7o7m8+/RzYsEtZacA
# 45vtofo345EXdFvlkUIejDGPRUAaSwU3B/yKF4piNUX1Xr6IztUaCz8t4IY5mu+I
# gXH2eW/H/l5rj8X7FbsbOYvhFn3r3arf76CK5mHeGn/hBXbltXbbk1G0PxuvOSOY
# Vv5H2XsNjylVyOJmLwl2yepjsyAfu6xiSXzmg7btDRW0AublNNzCsCGiGPZuUI0l
# t+SX0Ps1BUoh51v1MAbx37aoTfd7OxdLW2NVdjnGOiCYGtZuudTKK/LIcy4B8zRs
# Wb5H51LTA8WYAL0kozl4aSXT9uY2Rm+BjSbRLh1T5jgilVgCAz1+ebEQ3gKzGhG5
# IMoCDx6jAPLLpnYKgXkmDgIYK+Rv2A==
# SIG # End signature block
