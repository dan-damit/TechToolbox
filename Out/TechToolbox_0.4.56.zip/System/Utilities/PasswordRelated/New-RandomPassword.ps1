
function New-RandomPassword {
    [CmdletBinding(DefaultParameterSetName = 'Random')]
    param(
        [ValidateRange(8, 256)]
        [int]$Length = 12,

        # Random style only: number of required non-alphanumeric (symbols)
        [Parameter(ParameterSetName = 'Random')]
        [ValidateRange(0, 64)]
        [int]$NonAlpha = 0,

        [switch]$NoAmbiguous,

        [ValidateSet('Random', 'Readable', 'Passphrase')]
        [string]$Style = 'Readable',

        # Word-based styles
        [ValidateRange(2, 6)]
        [int]$Words = 2,

        [ValidateRange(1, 6)]
        [int]$Digits = 2,

        [string]$Separator = '-',

        [switch]$IncludeSymbol,

        [string]$WordListPath,

        [string[]]$DisallowTokens = @(' ', '$', 'admin', 'password', 'letmein', 'qwerty', '1234', 'abcd'), # common weak substrings to avoid

        [ValidateRange(1, 200)]
        [int]$MaxRegenerate = 50
    )

#region Setup
    # Character sets
    $UpperSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    $LowerSet = 'abcdefghijklmnopqrstuvwxyz'
    $DigitSet = '0123456789'
    $SymbolSet = '!@#$%^&*-+=?'

    if ($NoAmbiguous) {
        $UpperSet = 'ABCDEFGHJKLMNPQRSTUVWXYZ'      # no I, O
        $LowerSet = 'abcdefghijkmnpqrstuvwxyz'      # no l, o
        $DigitSet = '23456789'                      # no 0, 1
        # symbols ok as-is
    }

    # Crypto RNG helpers
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $hasGetInt32 = ([System.Security.Cryptography.RandomNumberGenerator].GetMethod('GetInt32', [type[]]@([int], [int])) -ne $null)
#endregion Setup

#region Helpers
    function Get-RandomIndex {
        param([int]$MaxExclusive)
        if ($MaxExclusive -le 0) { return 0 }
        if ($hasGetInt32) {
            return [System.Security.Cryptography.RandomNumberGenerator]::GetInt32(0, $MaxExclusive)
        }
        else {
            $b = New-Object byte[] 4
            $rng.GetBytes($b)
            return [Math]::Abs([BitConverter]::ToInt32($b, 0) % $MaxExclusive)
        }
    }

    function Get-RandomChar {
        param([string]$DigitSet)
        $DigitSet[(Get-RandomIndex $DigitSet.Length)]
    }

    function Get-RandomFromList {
        param([string[]]$List)
        $List[(Get-RandomIndex $List.Count)]
    }

    function Shuffle([char[]]$arr) {
        for ($i = $arr.Length - 1; $i -gt 0; $i--) {
            $j = Get-RandomIndex ($i + 1)
            if ($j -ne $i) {
                $tmp = $arr[$i]; $arr[$i] = $arr[$j]; $arr[$j] = $tmp
            }
        }
        -join $arr
    }

    function Import-WordList {
        param([string]$Path, [switch]$NoAmbiguous)
        $list = @()
        if ($Path -and (Test-Path -LiteralPath $Path)) {
            $list = Get-Content -LiteralPath $Path -ErrorAction Stop | Where-Object { $_ -match '^[A-Za-z]{3,10}$' }
        }
        if (-not $list -or $list.Count -lt 100) {
            # Fallback mini list if wordlist.txt fails to Import
            $list = @(
                'river', 'stone', 'blue', 'green', 'tiger', 'forest', 'echo', 'delta', 'nova', 'ember', 'maple', 'cedar', 'birch', 'pine',
                'silver', 'shadow', 'crimson', 'cobalt', 'onyx', 'raven', 'falcon', 'otter', 'fox', 'wolf', 'lynx', 'badger', 'eagle',
                'harbor', 'summit', 'meadow', 'prairie', 'canyon', 'valley', 'spring', 'autumn', 'winter', 'summer', 'breeze', 'cloud',
                'storm', 'thunder', 'rain', 'snow', 'frost', 'glacier', 'aurora', 'comet', 'meteor', 'orbit', 'quartz', 'granite', 'basalt',
                'pebble', 'coral', 'reef', 'tide', 'delta', 'lagoon', 'moss', 'fern', 'willow', 'aspen', 'spruce', 'hemlock', 'elm',
                'copper', 'iron', 'nickel', 'zinc', 'amber', 'topaz', 'agate', 'jade', 'opal', 'pearl', 'sapphire', 'ruby', 'garnet',
                'swift', 'brisk', 'rapid', 'steady', 'bold', 'bright', 'quiet', 'gentle', 'keen', 'vivid', 'lively', 'nimble', 'solid',
                'lofty', 'noble', 'true', 'prime', 'vantage', 'zenith', 'apex', 'vertex', 'vector', 'gamma', 'omega', 'alpha', 'sigma',
                'orbit', 'photon', 'quark', 'ion', 'pixel', 'matrix', 'cipher', 'beacon', 'signal', 'kernel', 'crypto', 'evergreen', 'lake'
            )
        }
        $list = $list | ForEach-Object { $_.ToLowerInvariant().Trim() } | Where-Object { $_ -ne '' } | Select-Object -Unique
        if ($NoAmbiguous) {
            $list = $list | Where-Object { $_ -notmatch '[ilo10]' } # filter words with ambiguous chars
        }
        return $list
    }

    function Confirm-Tokens {
        param([string]$Text, [string[]]$Tokens)
        foreach ($t in $Tokens) {
            if ([string]::IsNullOrWhiteSpace($t)) { continue }
            $tok = $t.Trim()
            if ($tok.Length -lt 3) { continue } # AD typically flags 3+ char sequences
            if ($Text -imatch [regex]::Escape($tok)) { return $true }
        }
        return $false
    }
#endregion Helpers

#region Main logic
    try {
        switch ($Style) {
            'Random' {
                # Ensure at least: 1 upper, 1 lower, 1 digit, + NonAlpha symbols
                $minRequired = 3 + $NonAlpha
                if ($Length -lt $minRequired) {
                    throw "Requested Length $Length is less than required minimum $minRequired (1 upper + 1 lower + 1 digit + $NonAlpha symbol(s))."
                }

                # Collect mandatory characters
                $chars = New-Object System.Collections.Generic.List[char]
                $chars.Add((Get-RandomChar $UpperSet))
                $chars.Add((Get-RandomChar $LowerSet))
                $chars.Add((Get-RandomChar $DigitSet))
                for ($i = 0; $i -lt $NonAlpha; $i++) { $chars.Add((Get-RandomChar $SymbolSet)) }

                # Fill remaining with union of sets (respecting NonAlpha=0 if you want no symbols)
                $all = ($UpperSet + $LowerSet + $DigitSet + ($NonAlpha -gt 0 ? $SymbolSet : '')).ToCharArray()
                while ($chars.Count -lt $Length) {
                    $chars.Add($all[(Get-RandomIndex $all.Length)])
                }

                # Shuffle & return
                $pwd = Shuffle ($chars.ToArray())
                return $pwd
            }

            'Readable' {
                # Make at least 2 words capitalized to ensure Upper+Lower, plus digits -> meets 3/4
                if ($Words -lt 2) { $Words = 2 }
                $wl = Import-WordList -Path $WordListPath -NoAmbiguous:$NoAmbiguous

                for ($attempt = 0; $attempt -lt $MaxRegenerate; $attempt++) {
                    $picked = for ($i = 1; $i -le $Words; $i++) { Get-RandomFromList $wl }
                    # Capitalize one random word to ensure uppercase category
                    $capIdx = Get-RandomIndex $picked.Count
                    for ($i = 0; $i -lt $picked.Count; $i++) {
                        if ($i -eq $capIdx) {
                            $picked[$i] = $picked[$i].Substring(0, 1).ToUpperInvariant() + $picked[$i].Substring(1).ToLowerInvariant()
                        }
                        else {
                            $picked[$i] = $picked[$i].ToLowerInvariant()
                        }
                    }

                    $core = ($picked -join $Separator)
                    $digitsStr = -join (1..$Digits | ForEach-Object { Get-RandomChar $DigitSet })
                    $candidate = $core + $digitsStr

                    if ($IncludeSymbol) {
                        $candidate += (Get-RandomChar $SymbolSet)
                    }

                    if ($candidate.Length -lt $Length) {
                        $padCount = $Length - $candidate.Length
                        $pad = -join (1..$padCount | ForEach-Object { Get-RandomChar $LowerSet })
                        $candidate += $pad
                    }

                    if ($DisallowTokens.Count -gt 0 -and (Confirm-Tokens -Text $candidate -Tokens $DisallowTokens)) {
                        continue
                    }

                    # Ensure categories: upper, lower, digit
                    if (($candidate -cmatch '[A-Z]') -and ($candidate -cmatch '[a-z]') -and ($candidate -match '\d')) {
                        return $candidate
                    }
                }
                throw "Failed to generate a Readable password after $MaxRegenerate attempts. Consider relaxing DisallowTokens/length."
            }

            'Passphrase' {
                # Typically 3+ words, lower/title with separator, + digits; length is a minimum
                if ($Words -lt 3) { $Words = 3 }
                $wl = Import-WordList -Path $WordListPath -NoAmbiguous:$NoAmbiguous

                for ($attempt = 0; $attempt -lt $MaxRegenerate; $attempt++) {
                    $picked = for ($i = 1; $i -le $Words; $i++) { Get-RandomFromList $wl }
                    # Capitalize one random word to ensure uppercase category
                    $capIdx = Get-RandomIndex $picked.Count
                    for ($i = 0; $i -lt $picked.Count; $i++) {
                        if ($i -eq $capIdx) {
                            $picked[$i] = $picked[$i].Substring(0, 1).ToUpperInvariant() + $picked[$i].Substring(1).ToLowerInvariant()
                        }
                        else {
                            $picked[$i] = $picked[$i].ToLowerInvariant()
                        }
                    }

                    $core = ($picked -join $Separator)
                    $digitsStr = -join (1..$Digits | ForEach-Object { Get-RandomChar $DigitSet })
                    $candidate = $core + $digitsStr

                    if ($IncludeSymbol) {
                        $candidate += (Get-RandomChar $SymbolSet)
                    }

                    if ($candidate.Length -lt $Length) {
                        $padCount = $Length - $candidate.Length
                        $pad = -join (1..$padCount | ForEach-Object { Get-RandomChar $LowerSet })
                        $candidate += $pad
                    }

                    if ($DisallowTokens.Count -gt 0 -and (Confirm-Tokens -Text $candidate -Tokens $DisallowTokens)) {
                        continue
                    }

                    # Ensure categories: upper, lower, digit
                    if (($candidate -cmatch '[A-Z]') -and ($candidate -cmatch '[a-z]') -and ($candidate -match '\d')) {
                        return $candidate
                    }
                }
                throw "Failed to generate a Passphrase after $MaxRegenerate attempts. Consider relaxing DisallowTokens/length."
            }
        }
    }
    finally {
        $rng.Dispose()
    }
}

#endregion Main logic


# SIG # Begin signature block
# MIIfAgYJKoZIhvcNAQcCoIIe8zCCHu8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCCYPh4Q+Viot5O
# WZoVdMNJLG9ocbHyadlpNS8AkV48WKCCGEowggUMMIIC9KADAgECAhAR+U4xG7FH
# qkyqS9NIt7l5MA0GCSqGSIb3DQEBCwUAMB4xHDAaBgNVBAMME1ZBRFRFSyBDb2Rl
# IFNpZ25pbmcwHhcNMjUxMjE5MTk1NDIxWhcNMjYxMjE5MjAwNDIxWjAeMRwwGgYD
# VQQDDBNWQURURUsgQ29kZSBTaWduaW5nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8A
# MIICCgKCAgEA3pzzZIUEY92GDldMWuzvbLeivHOuMupgpwbezoG5v90KeuN03S5d
# nM/eom/PcIz08+fGZF04ueuCS6b48q1qFnylwg/C/TkcVRo0WFcKoFGT8yGxdfXi
# caHtapZfbSRh73r7qR7w0CioVveNBVgfMsTgE0WKcuwxemvIe/ptmkfzwAiw/IAC
# Ib0E0BjiX4PySbwWy/QKy/qMXYY19xpRItVTKNBtXzADUtzPzUcFqJU83vM2gZFs
# Or0MhPvM7xEVkOWZFBAWAubbMCJ3rmwyVv9keVDJChhCeLSz2XR11VGDOEA2OO90
# Y30WfY9aOI2sCfQcKMeJ9ypkHl0xORdhUwZ3Wz48d3yJDXGkduPm2vl05RvnA4T6
# 29HVZTmMdvP2475/8nLxCte9IB7TobAOGl6P1NuwplAMKM8qyZh62Br23vcx1fXZ
# TJlKCxBFx1nTa6VlIJk+UbM4ZPm954peB/fIqEacm8LkZ0cPwmLE5ckW7hfK4Trs
# o+RaudU1sKeA+FvpOWgsPccVRWcEYyGkwbyTB3xrIBXA+YckbANZ0XL7fv7x29hn
# gXbZipGu3DnTISiFB43V4MhNDKZYfbWdxze0SwLe8KzIaKnwlwRgvXDMwXgk99Mi
# EbYa3DvA/5ZWikLW9PxBFD7Vdr8ZiG/tRC9I2Y6fnb+PVoZKc/2xsW0CAwEAAaNG
# MEQwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQW
# BBRfYLVE8caSc990rnrIHUjoB7X/KjANBgkqhkiG9w0BAQsFAAOCAgEAiGB2Wmk3
# QBtd1LcynmxHzmu+X4Y5DIpMMNC2ahsqZtPUVcGqmb5IFbVuAdQphL6PSrDjaAR8
# 1S8uTfUnMa119LmIb7di7TlH2F5K3530h5x8JMj5EErl0xmZyJtSg7BTiBA/UrMz
# 6WCf8wWIG2/4NbV6aAyFwIojfAcKoO8ng44Dal/oLGzLO3FDE5AWhcda/FbqVjSJ
# 1zMfiW8odd4LgbmoyEI024KkwOkkPyJQ2Ugn6HMqlFLazAmBBpyS7wxdaAGrl18n
# 6bS7QuAwCd9hitdMMitG8YyWL6tKeRSbuTP5E+ASbu0Ga8/fxRO5ZSQhO6/5ro1j
# PGe1/Kr49Uyuf9VSCZdNIZAyjjeVAoxmV0IfxQLKz6VOG0kGDYkFGskvllIpQbQg
# WLuPLJxoskJsoJllk7MjZJwrpr08+3FQnLkRuisjDOc3l4VxFUsUe4fnJhMUONXT
# Sk7vdspgxirNbLmXU4yYWdsizz3nMUR0zebUW29A+HYme16hzrMPOeyoQjy4I5XX
# 3wXAFdworfPEr/ozDFrdXKgbLwZopymKbBwv6wtT7+1zVhJXr+jGVQ1TWr6R+8ea
# tIOFnY7HqGaxe5XB7HzOwJKdj+bpHAfXft1vUoiKr16VajLigcYCG8MdwC3sngO3
# JDyv2V+YMfsYBmItMGBwvizlQ6557NbK95EwggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwgga0MIIEnKADAgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqG
# SIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRy
# dXN0ZWQgUm9vdCBHNDAeFw0yNTA1MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYg
# MjAyNSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphB
# cr48RsAcrHXbo0ZodLRRF51NrY0NlLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6p
# vF4uGjwjqNjfEvUi6wuim5bap+0lgloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHe
# HYNnQxqXmRinvuNgxVBdJkf77S2uPoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEd
# gkFiDNYiOTx4OtiFcMSkqTtF2hfQz3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjU
# jsZvkgFkriK9tUKJm/s80FiocSk1VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bR
# VFLeGkuAhHiGPMvSGmhgaTzVyhYn4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeS
# LsJygoLPp66bkDX1ZlAeSpQl92QOMeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIV
# NSaz7BX8VtYGqLt9MmeOreGPRdtBx3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL
# 6s36czwzsucuoKs7Yk/ehb//Wx+5kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2Zd
# SoQbU2rMkpLiQ6bGRinZbI4OLu9BMIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFU
# eEY0qVjPKOWug/G6X5uAiynM7Bu2ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/
# BAgwBgEB/wIBADAdBgNVHQ4EFgQU729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0j
# BBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8E
# PDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEw
# DQYJKoZIhvcNAQELBQADggIBABfO+xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/
# T8ObXAZz8OjuhUxjaaFdleMM0lBryPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQ
# E7jU/kXjjytJgnn0hvrV6hqWGd3rLAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9r
# EVKChHyfpzee5kH0F8HABBgr0UdqirZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y
# 1IsA0QF8dTXqvcnTmpfeQh35k5zOCPmSNq1UH410ANVko43+Cdmu4y81hjajV/gx
# dEkMx1NKU4uHQcKfZxAvBAKqMVuqte69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3t
# y9qIijanrUR3anzEwlvzZiiyfTPjLbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcy
# tL5TTLL4ZaoBdqbhOhZ3ZRDUphPvSRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEB
# YTptMSbhdhGQDpOXgpIUsWTjd6xpR6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud
# /v4+7RWsWCiKi9EOLLHfMR2ZyJ/+xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiS
# uEtQvLsNz3Qbp7wGWqbIiOWCnb5WqxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZP
# ubdcMIIG7TCCBNWgAwIBAgIQCoDvGEuN8QWC0cR2p5V0aDANBgkqhkiG9w0BAQsF
# ADBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hB
# MjU2IDIwMjUgQ0ExMB4XDTI1MDYwNDAwMDAwMFoXDTM2MDkwMzIzNTk1OVowYzEL
# MAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJE
# aWdpQ2VydCBTSEEyNTYgUlNBNDA5NiBUaW1lc3RhbXAgUmVzcG9uZGVyIDIwMjUg
# MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANBGrC0Sxp7Q6q5gVrMr
# V7pvUf+GcAoB38o3zBlCMGMyqJnfFNZx+wvA69HFTBdwbHwBSOeLpvPnZ8ZN+vo8
# dE2/pPvOx/Vj8TchTySA2R4QKpVD7dvNZh6wW2R6kSu9RJt/4QhguSssp3qome7M
# rxVyfQO9sMx6ZAWjFDYOzDi8SOhPUWlLnh00Cll8pjrUcCV3K3E0zz09ldQ//nBZ
# ZREr4h/GI6Dxb2UoyrN0ijtUDVHRXdmncOOMA3CoB/iUSROUINDT98oksouTMYFO
# nHoRh6+86Ltc5zjPKHW5KqCvpSduSwhwUmotuQhcg9tw2YD3w6ySSSu+3qU8DD+n
# igNJFmt6LAHvH3KSuNLoZLc1Hf2JNMVL4Q1OpbybpMe46YceNA0LfNsnqcnpJeIt
# K/DhKbPxTTuGoX7wJNdoRORVbPR1VVnDuSeHVZlc4seAO+6d2sC26/PQPdP51ho1
# zBp+xUIZkpSFA8vWdoUoHLWnqWU3dCCyFG1roSrgHjSHlq8xymLnjCbSLZ49kPmk
# 8iyyizNDIXj//cOgrY7rlRyTlaCCfw7aSUROwnu7zER6EaJ+AliL7ojTdS5PWPsW
# eupWs7NpChUk555K096V1hE0yZIXe+giAwW00aHzrDchIc2bQhpp0IoKRR7YufAk
# prxMiXAJQ1XCmnCfgPf8+3mnAgMBAAGjggGVMIIBkTAMBgNVHRMBAf8EAjAAMB0G
# A1UdDgQWBBTkO/zyMe39/dfzkXFjGVBDz2GM6DAfBgNVHSMEGDAWgBTvb1NK6eQG
# fHrK4pBW9i/USezLTjAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYB
# BQUHAwgwgZUGCCsGAQUFBwEBBIGIMIGFMCQGCCsGAQUFBzABhhhodHRwOi8vb2Nz
# cC5kaWdpY2VydC5jb20wXQYIKwYBBQUHMAKGUWh0dHA6Ly9jYWNlcnRzLmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEy
# NTYyMDI1Q0ExLmNydDBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vY3JsMy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hB
# MjU2MjAyNUNBMS5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcB
# MA0GCSqGSIb3DQEBCwUAA4ICAQBlKq3xHCcEua5gQezRCESeY0ByIfjk9iJP2zWL
# pQq1b4URGnwWBdEZD9gBq9fNaNmFj6Eh8/YmRDfxT7C0k8FUFqNh+tshgb4O6Lgj
# g8K8elC4+oWCqnU/ML9lFfim8/9yJmZSe2F8AQ/UdKFOtj7YMTmqPO9mzskgiC3Q
# YIUP2S3HQvHG1FDu+WUqW4daIqToXFE/JQ/EABgfZXLWU0ziTN6R3ygQBHMUBaB5
# bdrPbF6MRYs03h4obEMnxYOX8VBRKe1uNnzQVTeLni2nHkX/QqvXnNb+YkDFkxUG
# tMTaiLR9wjxUxu2hECZpqyU1d0IbX6Wq8/gVutDojBIFeRlqAcuEVT0cKsb+zJNE
# suEB7O7/cuvTQasnM9AWcIQfVjnzrvwiCZ85EE8LUkqRhoS3Y50OHgaY7T/lwd6U
# Arb+BOVAkg2oOvol/DJgddJ35XTxfUlQ+8Hggt8l2Yv7roancJIFcbojBcxlRcGG
# 0LIhp6GvReQGgMgYxQbV1S3CrWqZzBt1R9xJgKf47CdxVRd/ndUlQ05oxYy2zRWV
# FjF7mcr4C34Mj3ocCVccAvlKV9jEnstrniLvUxxVZE/rptb7IRE2lskKPIJgbaP5
# t2nGj/ULLi49xTcBZU8atufk+EMF/cWuiC7POGT75qaL6vdCvHlshtjdNXOCIUjs
# arfNZzGCBg4wggYKAgEBMDIwHjEcMBoGA1UEAwwTVkFEVEVLIENvZGUgU2lnbmlu
# ZwIQEflOMRuxR6pMqkvTSLe5eTANBglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3
# AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisG
# AQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCCUoKQF+P0P
# KJljl4edUTODOyxGA7TPlXnfset/z+P+AzANBgkqhkiG9w0BAQEFAASCAgB6dDpf
# yglugOtIAApwqQ1RItt0AGEGLhE+QPKJwfemi9kZ6Je2bwNRO/VneBPhCetqsXRs
# 2z56BrGL07doLj9qIlaEa4aKqeHQSvXFO5OxahqgCHKtNTn6wWbF6Do9CZB87V9B
# HDRI8aEDCW02ifv8t5MQtUYiKAljZ/a/FoA9mqOS7Hq3pMFobRHaRSeraKIFdbUm
# EUekbvYZgOELXDqcP0GJqiTCAq4meYWhXk6OUwrejP4Pn7FDE/MB6mw6NYDMhVJg
# zDWzQxb6hTeA6694UKpMuIaiqwW8wdpbQ0BWWsuZV0l1cPBuel/6rbwvpwu1R5Ip
# R7NCQVNBCgX3L2ADwnxsWT2aI9FHYHTX6BA3irx14De7cVqvi+3bodou9Q3fvC5Y
# rYQpLbWD5jTDWtk3UBXxknbbimCwtcFbRWXZTLx2Xagwmrpw5T3Bo8PYqlFXeh8W
# jMfi+Y+/zCKO7VVQxjBG5vxfxHhSt1/oiDwJvxskxW20AOna9mXoeAbz4vK/lEv3
# ev/lLxRapwDqTYueJwaXUkw1WewgGdByek1DjVpWt6rmU81qE4cwhQuGsISFvrC9
# 9GDplN46ok5JInIpMpIQ1opEufnuJq8ycmYHnOwpfYsMqnqJUc3AGRhj/5zlW5zg
# bXrzIB5NxBm3oGb7FK2+P61eVZz2PmLbxn/QtaGCAyYwggMiBgkqhkiG9w0BCQYx
# ggMTMIIDDwIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcg
# UlNBNDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgwDQYJYIZI
# AWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJ
# BTEPFw0yNjA0MDYxODA2NTFaMC8GCSqGSIb3DQEJBDEiBCCNcbG8WZYPt9X8n4ID
# KfKa3p8OKTTOwoKYbzedomqXJTANBgkqhkiG9w0BAQEFAASCAgCLr5TnYIYCx5iG
# Wo91qDZs+2dYiva44r2hw51GZ2OSOITw3O1UhhVXK//PMOf4MP64ttGSPbaxyakO
# gbDkOMuR+sc1Uhq9z0jxaKNpz2ylBAbV7kkwPmKL7HYzLsTKuslgGVoinX4Ip/Vi
# GvSxKU3Jf73wFINDC8U3jCn2lqeCG2PelzMMe0UAibqRsj6n3dSOhw32yW+Hz86o
# 9o6QBYF3AQG/eXDceUufuKcXbr2nBwjVvTZmjZUUZ8IbuuE+YoBfX9tkl8zPYEL7
# 05akFO4CiYibjsSHgrww8X3ebBhdPg2wFZw/aRFP2eBHFX+MFCSp5S0dI1H37+8K
# xIGDM4J3LXarkkC9K9GBaopWk/q6GAz1JQVugFUBuaXtzE+mc7GVfaRTTl2OZr1p
# IW91lwnclq/fhYKOmDoGZamEvCyEG4ySjm4MroOD+6kQnmY+9y5hTGRGCAr4/79g
# EJbJsQAfDMot75rWqjZXgwLrhbh73FAT/OjOGKarc50NrmXNx6cherjyqRmhfpst
# x/WuBNeCMzIaBqP68weOgz/Zzevl9+ClyS2Whdj/TU1SSPb+W1sq/G9sk+oEjjiQ
# RRdZBNsry0cw7hCjImkfHakG/dsrAhiP4t7DbBNRWrId2oAtsn+2l1Yg9gLVRtuG
# 4Rw6HKToVd/Rg5l25cQf3DxSgRs85w==
# SIG # End signature block
