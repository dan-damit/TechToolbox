function Reset-ADPassword {
    <#
    .SYNOPSIS
    Resets an AD user's password using TechToolbox's private password generator.

    .DESCRIPTION
    - Attempts to dot-source Private\Passwords\Get-NewPassword.ps1 (or a path
      you specify)
    - Calls Get-NewPassword with optional parameters; defaults are read from
      $script:cfg by your function
    - Falls back to $candidate if generator sets it instead of returning a value
    - Resets AD password; optional Unlock and ChangePasswordAtLogon
    - Logging via Write-Log; no progress UI

    .PARAMETER Identity
    The AD user identity (sAMAccountName, UPN, or DN).

    .PARAMETER ChangePasswordAtLogon
    Set "User must change password at next logon".

    .PARAMETER Unlock
    Unlock the account after resetting the password.

    .PARAMETER OutFile
    Write the plaintext password to a file (plaintext).

    .PARAMETER Clipboard
    Copy plaintext password to clipboard (Windows only).

    .PARAMETER Credential
    (Reserved) Credential parameter to satisfy TechToolbox module interface.
    Currently not used inside this function.

    .EXAMPLE
    Reset-ADPassword -Identity jdoe -ChangePasswordAtLogon -Clipboard

    .EXAMPLE
    Reset-ADPassword -Identity jdoe -Unlock -OutFile C:\temp\jdoe_password.txt

    .EXAMPLE
    Reset-ADPassword -Identity jdoe -ChangePasswordAtLogon:$false
    #>
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Identity,

        [switch]$ChangePasswordAtLogon = $true,
        [switch]$Unlock,

        [ValidateSet('Random', 'Readable', 'Passphrase')]
        [string]$Style = 'Readable',

        [string]$OutFile,
        [switch]$Clipboard,

        [System.Management.Automation.PSCredential]$Credential
    )

    Initialize-TechToolboxRuntime
    $PasswordFunctionPath = $script:cfg.settings.resetPassword.passwordFunctionPath
    $InitialPasswordLength = $script:cfg.settings.resetPassword.initialPasswordLength
    $ShowPassword = $script:cfg.settings.resetPassword.showPassword
    $Separator = $script:cfg.settings.passwords.default.separator
    Write-Log -Level Info -Message "Starting Reset-ADPassword for '$Identity'"

    Get-ActiveDirectoryModule

    if (-not (Get-Module ActiveDirectory) -and -not (Get-Module ActiveDirectory -ListAvailable)) {
        Write-Log -Level Error -Message "ActiveDirectory module unavailable. Install RSAT or ensure AD tools are accessible."
        throw "Missing ActiveDirectory module."
    }

    # --- Generate the password (prefer return value; fallback to $candidate)
    $InitialPassword = Get-NewPassword -length $InitialPasswordLength -separator $Separator -Style $Style
    $SecurePass = ConvertTo-SecureString $initialPassword -AsPlainText -Force

    # --- Resolve AD user ---
    try {
        $user = Get-ADUser -Identity $Identity -Properties LockedOut, PasswordExpired -Credential $Credential -ErrorAction Stop
        Write-Log -Level Info -Message "Resolved AD user '$($user.SamAccountName)'"
    }
    catch {
        Write-Log -Level Error -Message "Failed to resolve user '$Identity': $($_.Exception.Message)"
        throw
    }

    # --- Reset password ---
    if ($PSCmdlet.ShouldProcess($user.SamAccountName, "Reset AD password")) {
        try {
            Set-ADAccountPassword -Identity $user.DistinguishedName -NewPassword $securePass -Reset -Credential $Credential -ErrorAction Stop
            Write-Log -Level Ok -Message "Password reset successful for '$($user.SamAccountName)'"
        }
        catch {
            Write-Log -Level Error -Message "Password reset failed for '$($user.SamAccountName)': $($_.Exception.Message)"
            throw
        }
    }

    # --- Optional unlock ---
    if ($Unlock) {
        try {
            Unlock-ADAccount -Identity $user.DistinguishedName -Credential $Credential -ErrorAction Stop
            Write-Log -Level Ok -Message "Account unlocked: $($user.SamAccountName)"
        }
        catch {
            Write-Log -Level Warn -Message "Failed to unlock account: $($_.Exception.Message)"
        }
    }

    # --- Optional change-at-logon ---
    if ($ChangePasswordAtLogon) {
        try {
            Set-ADUser -Identity $user.DistinguishedName -ChangePasswordAtLogon $true -Credential $Credential -ErrorAction Stop
            Write-Log -Level Ok -Message "ChangePasswordAtLogon set for: $($user.SamAccountName)"
        }
        catch {
            Write-Log -Level Warn -Message "Failed to set ChangePasswordAtLogon: $($_.Exception.Message)"
        }
    }

    # --- Delivery controls (opt-in only) ---
    if ($ShowPassword) {
        Write-Log -Level Warn -Message "Displaying password as requested:"
        Write-Log -Level Warn -Message "$initialPassword"
    }

    if ($OutFile) {
        try {
            $parent = Split-Path $OutFile -Parent
            if ($parent -and -not (Test-Path $parent)) {
                New-Item -Path $parent -ItemType Directory -Force | Out-Null
            }
            Set-Content -Path $OutFile -Value $initialPassword -NoNewline -Force
            Write-Log -Level Info -Message "Password written to file: $OutFile (plaintext)"
        }
        catch {
            Write-Log -Level Warn -Message "Failed to write password to '$OutFile': $($_.Exception.Message)"
        }
    }

    if ($Clipboard) {
        if ($IsWindows) {
            try {
                $null = $initialPassword | clip.exe
                Write-Log -Level Info -Message "Password copied to clipboard."
            }
            catch {
                Write-Log -Level Warn -Message "Failed to copy to clipboard: $($_.Exception.Message)"
            }
        }
        else {
            Write-Log -Level Warn -Message "Clipboard copy is only supported on Windows."
        }
    }

    Write-Log -Level Ok -Message "Completed Reset-ADPassword for '$($user.SamAccountName)'"
    [pscustomobject]@{
        SamAccountName        = $user.SamAccountName
        DistinguishedName     = $user.DistinguishedName
        ChangePasswordAtLogon = [bool]$ChangePasswordAtLogon
        Unlocked              = [bool]$Unlock
        PasswordDelivery      = @(
            $(if ($ShowPassword) { 'Console' })
            $(if ($OutFile) { 'File' })
            $(if ($Clipboard) { 'Clipboard' })
        ) -join ','
        Timestamp             = (Get-Date)
    }
}

# SIG # Begin signature block
# MIIfAgYJKoZIhvcNAQcCoIIe8zCCHu8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAnaMe5L418P31U
# lDxlu/9vU7ooe9o2plBLEX03348mm6CCGEowggUMMIIC9KADAgECAhAR+U4xG7FH
# qkyqS9NIt7l5MA0GCSqGSIb3DQEBCwUAMB4xHDAaBgNVBAMME1ZBRFRFSyBDb2Rl
# IFNpZ25pbmcwHhcNMjUxMjE5MTk1NDIxWhcNMjYxMjE5MjAwNDIxWjAeMRwwGgYD
# VQQDDBNWQURURUsgQ29kZSBTaWduaW5nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8A
# MIICCgKCAgEA3pzzZIUEY92GDldMWuzvbLeivHOuMupgpwbezoG5v90KeuN03S5d
# nM/eom/PcIz08+fGZF04ueuCS6b48q1qFnylwg/C/TkcVRo0WFcKoFGT8yGxdfXi
# caHtapZfbSRh73r7qR7w0CioVveNBVgfMsTgE0WKcuwxemvIe/ptmkfzwAiw/IAC
# Ib0E0BjiX4PySbwWy/QKy/qMXYY19xpRItVTKNBtXzADUtzPzUcFqJU83vM2gZFs
# Or0MhPvM7xEVkOWZFBAWAubbMCJ3rmwyVv9keVDJChhCeLSz2XR11VGDOEA2OO90
# Y30WfY9aOI2sCfQcKMeJ9ypkHl0xORdhUwZ3Wz48d3yJDXGkduPm2vl05RvnA4T6
# 29HVZTmMdvP2475/8nLxCte9IB7TobAOGl6P1NuwplAMKM8qyZh62Br23vcx1fXZ
# TJlKCxBFx1nTa6VlIJk+UbM4ZPm954peB/fIqEacm8LkZ0cPwmLE5ckW7hfK4Trs
# o+RaudU1sKeA+FvpOWgsPccVRWcEYyGkwbyTB3xrIBXA+YckbANZ0XL7fv7x29hn
# gXbZipGu3DnTISiFB43V4MhNDKZYfbWdxze0SwLe8KzIaKnwlwRgvXDMwXgk99Mi
# EbYa3DvA/5ZWikLW9PxBFD7Vdr8ZiG/tRC9I2Y6fnb+PVoZKc/2xsW0CAwEAAaNG
# MEQwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQW
# BBRfYLVE8caSc990rnrIHUjoB7X/KjANBgkqhkiG9w0BAQsFAAOCAgEAiGB2Wmk3
# QBtd1LcynmxHzmu+X4Y5DIpMMNC2ahsqZtPUVcGqmb5IFbVuAdQphL6PSrDjaAR8
# 1S8uTfUnMa119LmIb7di7TlH2F5K3530h5x8JMj5EErl0xmZyJtSg7BTiBA/UrMz
# 6WCf8wWIG2/4NbV6aAyFwIojfAcKoO8ng44Dal/oLGzLO3FDE5AWhcda/FbqVjSJ
# 1zMfiW8odd4LgbmoyEI024KkwOkkPyJQ2Ugn6HMqlFLazAmBBpyS7wxdaAGrl18n
# 6bS7QuAwCd9hitdMMitG8YyWL6tKeRSbuTP5E+ASbu0Ga8/fxRO5ZSQhO6/5ro1j
# PGe1/Kr49Uyuf9VSCZdNIZAyjjeVAoxmV0IfxQLKz6VOG0kGDYkFGskvllIpQbQg
# WLuPLJxoskJsoJllk7MjZJwrpr08+3FQnLkRuisjDOc3l4VxFUsUe4fnJhMUONXT
# Sk7vdspgxirNbLmXU4yYWdsizz3nMUR0zebUW29A+HYme16hzrMPOeyoQjy4I5XX
# 3wXAFdworfPEr/ozDFrdXKgbLwZopymKbBwv6wtT7+1zVhJXr+jGVQ1TWr6R+8ea
# tIOFnY7HqGaxe5XB7HzOwJKdj+bpHAfXft1vUoiKr16VajLigcYCG8MdwC3sngO3
# JDyv2V+YMfsYBmItMGBwvizlQ6557NbK95EwggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwgga0MIIEnKADAgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqG
# SIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRy
# dXN0ZWQgUm9vdCBHNDAeFw0yNTA1MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYg
# MjAyNSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphB
# cr48RsAcrHXbo0ZodLRRF51NrY0NlLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6p
# vF4uGjwjqNjfEvUi6wuim5bap+0lgloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHe
# HYNnQxqXmRinvuNgxVBdJkf77S2uPoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEd
# gkFiDNYiOTx4OtiFcMSkqTtF2hfQz3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjU
# jsZvkgFkriK9tUKJm/s80FiocSk1VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bR
# VFLeGkuAhHiGPMvSGmhgaTzVyhYn4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeS
# LsJygoLPp66bkDX1ZlAeSpQl92QOMeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIV
# NSaz7BX8VtYGqLt9MmeOreGPRdtBx3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL
# 6s36czwzsucuoKs7Yk/ehb//Wx+5kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2Zd
# SoQbU2rMkpLiQ6bGRinZbI4OLu9BMIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFU
# eEY0qVjPKOWug/G6X5uAiynM7Bu2ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/
# BAgwBgEB/wIBADAdBgNVHQ4EFgQU729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0j
# BBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8E
# PDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEw
# DQYJKoZIhvcNAQELBQADggIBABfO+xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/
# T8ObXAZz8OjuhUxjaaFdleMM0lBryPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQ
# E7jU/kXjjytJgnn0hvrV6hqWGd3rLAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9r
# EVKChHyfpzee5kH0F8HABBgr0UdqirZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y
# 1IsA0QF8dTXqvcnTmpfeQh35k5zOCPmSNq1UH410ANVko43+Cdmu4y81hjajV/gx
# dEkMx1NKU4uHQcKfZxAvBAKqMVuqte69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3t
# y9qIijanrUR3anzEwlvzZiiyfTPjLbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcy
# tL5TTLL4ZaoBdqbhOhZ3ZRDUphPvSRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEB
# YTptMSbhdhGQDpOXgpIUsWTjd6xpR6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud
# /v4+7RWsWCiKi9EOLLHfMR2ZyJ/+xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiS
# uEtQvLsNz3Qbp7wGWqbIiOWCnb5WqxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZP
# ubdcMIIG7TCCBNWgAwIBAgIQCoDvGEuN8QWC0cR2p5V0aDANBgkqhkiG9w0BAQsF
# ADBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hB
# MjU2IDIwMjUgQ0ExMB4XDTI1MDYwNDAwMDAwMFoXDTM2MDkwMzIzNTk1OVowYzEL
# MAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJE
# aWdpQ2VydCBTSEEyNTYgUlNBNDA5NiBUaW1lc3RhbXAgUmVzcG9uZGVyIDIwMjUg
# MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANBGrC0Sxp7Q6q5gVrMr
# V7pvUf+GcAoB38o3zBlCMGMyqJnfFNZx+wvA69HFTBdwbHwBSOeLpvPnZ8ZN+vo8
# dE2/pPvOx/Vj8TchTySA2R4QKpVD7dvNZh6wW2R6kSu9RJt/4QhguSssp3qome7M
# rxVyfQO9sMx6ZAWjFDYOzDi8SOhPUWlLnh00Cll8pjrUcCV3K3E0zz09ldQ//nBZ
# ZREr4h/GI6Dxb2UoyrN0ijtUDVHRXdmncOOMA3CoB/iUSROUINDT98oksouTMYFO
# nHoRh6+86Ltc5zjPKHW5KqCvpSduSwhwUmotuQhcg9tw2YD3w6ySSSu+3qU8DD+n
# igNJFmt6LAHvH3KSuNLoZLc1Hf2JNMVL4Q1OpbybpMe46YceNA0LfNsnqcnpJeIt
# K/DhKbPxTTuGoX7wJNdoRORVbPR1VVnDuSeHVZlc4seAO+6d2sC26/PQPdP51ho1
# zBp+xUIZkpSFA8vWdoUoHLWnqWU3dCCyFG1roSrgHjSHlq8xymLnjCbSLZ49kPmk
# 8iyyizNDIXj//cOgrY7rlRyTlaCCfw7aSUROwnu7zER6EaJ+AliL7ojTdS5PWPsW
# eupWs7NpChUk555K096V1hE0yZIXe+giAwW00aHzrDchIc2bQhpp0IoKRR7YufAk
# prxMiXAJQ1XCmnCfgPf8+3mnAgMBAAGjggGVMIIBkTAMBgNVHRMBAf8EAjAAMB0G
# A1UdDgQWBBTkO/zyMe39/dfzkXFjGVBDz2GM6DAfBgNVHSMEGDAWgBTvb1NK6eQG
# fHrK4pBW9i/USezLTjAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYB
# BQUHAwgwgZUGCCsGAQUFBwEBBIGIMIGFMCQGCCsGAQUFBzABhhhodHRwOi8vb2Nz
# cC5kaWdpY2VydC5jb20wXQYIKwYBBQUHMAKGUWh0dHA6Ly9jYWNlcnRzLmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEy
# NTYyMDI1Q0ExLmNydDBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vY3JsMy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hB
# MjU2MjAyNUNBMS5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcB
# MA0GCSqGSIb3DQEBCwUAA4ICAQBlKq3xHCcEua5gQezRCESeY0ByIfjk9iJP2zWL
# pQq1b4URGnwWBdEZD9gBq9fNaNmFj6Eh8/YmRDfxT7C0k8FUFqNh+tshgb4O6Lgj
# g8K8elC4+oWCqnU/ML9lFfim8/9yJmZSe2F8AQ/UdKFOtj7YMTmqPO9mzskgiC3Q
# YIUP2S3HQvHG1FDu+WUqW4daIqToXFE/JQ/EABgfZXLWU0ziTN6R3ygQBHMUBaB5
# bdrPbF6MRYs03h4obEMnxYOX8VBRKe1uNnzQVTeLni2nHkX/QqvXnNb+YkDFkxUG
# tMTaiLR9wjxUxu2hECZpqyU1d0IbX6Wq8/gVutDojBIFeRlqAcuEVT0cKsb+zJNE
# suEB7O7/cuvTQasnM9AWcIQfVjnzrvwiCZ85EE8LUkqRhoS3Y50OHgaY7T/lwd6U
# Arb+BOVAkg2oOvol/DJgddJ35XTxfUlQ+8Hggt8l2Yv7roancJIFcbojBcxlRcGG
# 0LIhp6GvReQGgMgYxQbV1S3CrWqZzBt1R9xJgKf47CdxVRd/ndUlQ05oxYy2zRWV
# FjF7mcr4C34Mj3ocCVccAvlKV9jEnstrniLvUxxVZE/rptb7IRE2lskKPIJgbaP5
# t2nGj/ULLi49xTcBZU8atufk+EMF/cWuiC7POGT75qaL6vdCvHlshtjdNXOCIUjs
# arfNZzGCBg4wggYKAgEBMDIwHjEcMBoGA1UEAwwTVkFEVEVLIENvZGUgU2lnbmlu
# ZwIQEflOMRuxR6pMqkvTSLe5eTANBglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3
# AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisG
# AQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCAnaMmuvCDm
# IZRIdv3/YW1+l6WvpHCtgWXrvvhATV98sjANBgkqhkiG9w0BAQEFAASCAgAY916d
# xnqqbr1+5CPWRSqlzQ7021DIe7zbIjBwL825l+eoVygtIdvjAGyqt8ZI0QeAVlGW
# 8BR/Llwj13rxYlxxc46zX2G7tTPV6bTioHSIfCadoav9hTeKYZGVe1Jx0lUGYqLE
# 7rQTA4IqAwwoepE2ZmvbioQrggx9ltce0gmfZVg/hMRpQPgxsSn8/HU4ky9wKjYk
# lIsk/Yq95nHHBILrQR58quGXeOi3GouqeSE455jjuoeaQYYupwx2ObDsi+oQ+9xP
# eCVrlR7+yvXibjuDXvtcqfom0fZNM8YoqrOLpvBgbpDzTQx9ucpUbnmEakec+Uca
# 9/iWw9+ZwocyMkKbKO7prdzIDAj39EKJktYD4lnXP5PvkWyRgsu2KEToobJ45qkQ
# T7P+xbAzc0uTthksKDQsz7L7zxtrNbm2Wi/KPdvQtNFez5q+mPdjkH909isJsbVJ
# gx7KmQQua5jEMBEH4vTrOo/IymHyjnjXibt4oX/dn8vhUxJqJ1qLYhlcP1ESxBcK
# 8/XOPoJvlPQB43pyB28iofKh6gH5T79HnwnXPLLsJhwVg4qRnkyteK99j9Tg4zQh
# jjGweEXbJpOj1inQyh56jeGEJI/2/k+stndgg6lFpogVgXTsZCTdqD/Fgf2EM/NH
# 5cunYAp7v/jy/yU88g1iwTRs5ax/ddaUlYcs9qGCAyYwggMiBgkqhkiG9w0BCQYx
# ggMTMIIDDwIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcg
# UlNBNDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgwDQYJYIZI
# AWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJ
# BTEPFw0yNjA0MDYxNTAwMzlaMC8GCSqGSIb3DQEJBDEiBCAaB57ObaMkboMKOyI0
# 0V5vj6AE4amSOOkHXemgyERH3DANBgkqhkiG9w0BAQEFAASCAgDED/We6z+nPaCm
# scfwYa7lw4+QfdZbAjrh/oli3KA4OMzXN2xG3L/l3tp6LhV/buzF8oD7kQE7uGjp
# 5zVoU5qDrGhm8Cy1uQ77HvpNzBWaiGvdcZkRi7Xrhrw+1kk/QofTo55WdliTuOE5
# ejceAtXstpdCf5J8rdZ+vTsUqVffbqmhuEw+01e9lpjSi9R8D/1wame76qVyUslH
# njFHDnI6cAWXPngeQn+i+30mPO/9YKl/fJt5gKxg6975YHEhimSpbTBiOguw0mD9
# ZTXqu5/vPZNAMaoDnrfGxd9kL/0496Did+ElMg7N/iXdZcbLwNkkM3qU7ylpdUcD
# yjC+l1ulksY2O0pgo/w1Ld2ojfmFqygz4z+rVdX3Sx4PZ2W1FO0uYUb+nx07tPEj
# 5rFXdgrtukrP0ic31w+itCrcgXygxYiFnPZnS/K0kM8E/fHTPQI2qSOJNKps6A9L
# ExaM9MSV2oHr1k3gympJ+ddTjh+6C1/Scnwh/J/3NBg3MgHsgg33HiUmBVFH2Ouc
# D1UGclSFSmg2NcpUDaAO8jv/I/uL6SPYa3v6fCc9jC4sdG/JjRnuCMEISBq59DQU
# WTE4efW62ip5rRoMdOD5GAEVuMqcITG8iDM63KFOzDKR8ihLMwbU690yxhX7NUq4
# BHiCwOOQThZY8kcbcajDGcPasDyivw==
# SIG # End signature block
